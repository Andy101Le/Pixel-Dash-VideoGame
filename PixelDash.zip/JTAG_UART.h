/* function prototypes */
void put_jtag(volatile int *, char);
char get_jtag(volatile int *);
